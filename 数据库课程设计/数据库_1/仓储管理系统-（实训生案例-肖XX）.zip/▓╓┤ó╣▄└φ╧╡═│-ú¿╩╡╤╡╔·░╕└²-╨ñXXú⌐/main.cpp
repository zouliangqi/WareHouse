#include "myclass.h"


int main()
{
	Login login;
	login.logmenu();
	return 0;
}
